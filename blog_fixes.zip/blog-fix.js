// Client-side blog post redirect handler
document.addEventListener('DOMContentLoaded', function() {
  // Get current path
  const path = window.location.pathname;
  
  // Check if it's a blog post URL without .html
  if (path.startsWith('/blog/') && !path.endsWith('.html')) {
    // Redirect to the HTML version
    window.location.href = `${path}.html`;
  }
}); 