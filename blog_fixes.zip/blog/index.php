<?php
// Get the requested URI
$uri = $_SERVER['REQUEST_URI'];

// Extract the blog post slug
$path = parse_url($uri, PHP_URL_PATH);
$parts = explode('/', $path);
$slug = end($parts);

// If there's no slug, redirect to main blog page
if (empty($slug) || $slug === 'blog') {
    header('Location: /blog.html');
    exit;
}

// If the slug doesn't end with .html, redirect to the HTML version
if (!preg_match('/\.html$/', $slug)) {
    header('Location: /blog/' . $slug . '.html');
    exit;
}

// If the file exists, serve it
$file = __DIR__ . '/' . $slug;
if (file_exists($file)) {
    // Set the appropriate content type
    $extension = pathinfo($file, PATHINFO_EXTENSION);
    if ($extension === 'html') {
        header('Content-Type: text/html');
    }
    
    // Output the file contents
    readfile($file);
    exit;
}

// Otherwise redirect to 404
header('Location: /404.html');
exit;
?> 